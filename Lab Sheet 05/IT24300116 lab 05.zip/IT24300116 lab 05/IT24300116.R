setwd("C:\\Users\\Acer\\Desktop\\IT24300116 lab 05")
getwd()

#Q1
delivery_data <- read.table("Exercise - Lab 05.txt", header=TRUE,sep=",")
names(delivery_data)<- "Delivery_Time"
attach(delivery_data)
fix(delivery_data)

#Q2
hist(Delivery_Time,
     main = "Histogram of Delivery Times",
     breaks = seq(20, 70, length = 10),
     right = FALSE,
     xlab = "Delivery Time (minutes)",
     col = "lightblue")

#Q4
times <- delivery_data$Delivery_Time

breaks <- seq(20, 70, length.out = 10)

freq <- hist(times, breaks = breaks, right = FALSE, plot = FALSE)

cum_freq <- cumsum(freq$counts)

plot(breaks[-1], cum_freq, type = "o", col = "blue",
     lwd = 2, pch = 16,
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency")

